nano /home/pi/backup.sh

list=$(cat /home/pi/.rclone/backup.list)
for i in $list
do
        echo Пробуем "$i"
        sudo rclone sync -P --filter-from /home/pi/.rclone/excludes "$i" yandex:RASPBERRY"$i"
done
